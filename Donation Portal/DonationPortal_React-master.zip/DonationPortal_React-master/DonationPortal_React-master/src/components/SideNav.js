import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import { Link } from "react-router-dom";

class SideNav extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.uid
    };
  }
  render() {
    return (
      <div className="form-container-dashboard">
        <div id="slide-out" className="side-nav fixed">
          {/* <div className="logo-wrapper waves-light">
            <a href="#">
              <img
                className="img-fluid flex-center"
                alt="Can't load it right now. Please check your connection and try again."
              />
            </a>
          </div> */}

          <ul className="custom-scrollbar">
            <li>
              <Link to={"/udon/Clothes/" + this.state.uid}>
                <a>clothes</a>
              </Link>
            </li>
            <li>
              <Link to={"/udon/Utensils/" + this.state.uid}>
                <a>utensils</a>
              </Link>
            </li>
            <li>
              <Link to={"/udon/Toys/" + this.state.uid}>
                <a>toys</a>
              </Link>
            </li>
            <li>
              <Link to={"/udon/Books/" + this.state.uid}>
                <a>books</a>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}

export default SideNav;
