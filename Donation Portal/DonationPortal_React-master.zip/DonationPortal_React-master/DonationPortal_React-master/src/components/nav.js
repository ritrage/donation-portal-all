import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Axios from "axios";

class Nav extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.uid,
      type: this.props.type,
      homeUserUrl: "/udash/" + this.props.uid,
      accUserUrl: "/acc/u/" + this.props.uid,
      homeNgoUrl: "/ndash/" + this.props.uid,
      accNgoUrl: "/acc/n/" + this.props.uid,
      getUrl: "http://localhost:8080/user/" + this.props.uid + "/",
      getNgoUrl: "http://localhost:8080/ngo/" + this.props.uid + "/",
      username: ""
    };
  }
  componentDidMount() {
    console.log(this.state.type);
    if (this.state.type === "USER") {
      Axios.get(this.state.getUrl).then(res => {
        this.setState({
          username: res.data.username
        });
      });
    } else if (this.state.type === "NGO") {
      Axios.get(this.state.getNgoUrl).then(res => {
        this.setState({
          username: res.data.ngoName
        });
      });
    }
  }

  render() {
    var username = this.state.username;

    return (
      <nav className="navbar fixed-top navbar-expand-lg navbar-light bg-light">
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarNavDropdown">
          <ul className="navbar-nav w-100">
            <li className="nav-item active">
              <a
                className="nav-link"
                href={
                  this.state.type === "USER"
                    ? this.state.homeUserUrl
                    : this.state.homeNgoUrl
                }
              >
                Home <span className="sr-only">(current)</span>
              </a>
            </li>

            <li className="nav-item dropdown ml-auto">
              <a
                className="nav-link dropdown-toggle"
                href="#"
                id="navbarDropdownMenuLink"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                <span className="glyphicon glyphicon-user" /> {" " + username}
              </a>
              <div
                className="dropdown-menu dropdown-menu-right"
                aria-labelledby="navbarDropdownMenuLink"
              >
                <a
                  className="dropdown-item"
                  href={
                    this.state.type === "USER"
                      ? this.state.accUserUrl
                      : this.state.accNgoUrl
                  }
                >
                  Account Details
                </a>
                <a className="dropdown-item" href="/login">
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    );
  }
}

export default Nav;
