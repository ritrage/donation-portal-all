import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import { Link } from "react-router-dom";
import Nav from "./nav";
import Axios from "axios";

class UserDashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.match.params.id,
      url: "http://localhost:8080/user/" + this.props.match.params.id + "/",
      username: "User",
      nextUrl: "/udon/Books/" + this.props.match.params.id,
      type: "USER",
      pendingCountUrl:
        "http://localhost:8080/donation/count/user/" +
        this.props.match.params.id +
        "/PENDING/",
      doneCountUrl:
        "http://localhost:8080/donation/count/user/" +
        this.props.match.params.id +
        "/COMPLETED/",
      pendingQuantity: null,
      doneQuantity: null
    };
  }

  componentDidMount() {
    const doneCountUrl = this.state.doneCountUrl;
    Axios.get(doneCountUrl).then(res => {
      console.log(res.data);
      this.setState({
        doneQuantity: res.data
      });
    });
    const pendingCountUrl = this.state.pendingCountUrl;
    Axios.get(pendingCountUrl).then(res => {
      console.log(res.data);
      this.setState({
        pendingQuantity: res.data
      });
    });
    const userId = this.state.url;
    Axios.get(userId).then(res => {
      console.log(res.data);
      this.setState({
        username: res.data.username
      });
    });
  }

  render() {
    return (
      <div>
        {/* {this.donDone} */}
        <Nav uid={this.state.uid} type={this.state.type} />
        <div className="form-container-pavbhaji">
          <h1 align="center">Welcome {this.state.username}</h1>
          <div className="card">
            <div className="card-header">Donations</div>
            <div className="card-body">
              <p className="card-text">
                Donations Done: {this.state.doneQuantity}
              </p>
              <Link to={"/detailsc/" + this.state.uid}>
                <button className="btn btn-success mybtn" onClick="#">
                  View details
                </button>
              </Link>
              <p className="card-text">
                Donations Pending: {this.state.pendingQuantity}
              </p>
              <Link to={"/detailsp/" + this.state.uid}>
                <button className="btn btn-warning mybtn">View details</button>
              </Link>
            </div>
          </div>
          <div className="text-center">
            <Link to={this.state.nextUrl}>
              <button className="btn btn-primary mybtn">Donate</button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default UserDashboard;
