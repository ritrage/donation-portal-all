import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Axios from "axios";
import { Redirect } from "react-router-dom";
import { Typography } from "@material-ui/core";

class UserSignUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username_signup: "",
      email: "",
      contact: "",
      address: "",
      city: "",
      password_signup: "",
      confirm_password: "",
      isSignedUp: false,
      errors: "",
      nextUrl: ""
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.onChangeconfirmpassword = this.onChangeconfirmpassword.bind(this);
    this.onChangeaddress = this.onChangeaddress.bind(this);
    this.onChangecity = this.onChangecity.bind(this);
    this.onChangecontact = this.onChangecontact.bind(this);
    this.onChangeemail = this.onChangeemail.bind(this);
    this.onChangefullname = this.onChangefullname.bind(this);
    this.onChangepassword = this.onChangepassword.bind(this);
    this.onChangeusername = this.onChangeusername.bind(this);
  }

  handleSubmit(event) {
    event.preventDefault();
    if (this.state.password_signup === this.state.confirm_password) {
      const user = {
        username: this.state.username_signup,
        email: this.state.email,
        contact: this.state.contact,
        address: this.state.address,
        city: this.state.city,
        password: this.state.password_signup
      };

      Axios.post("http://localhost:8080/user/", user).then(res => {
        console.log(res.data);
        if (res.data.id !== null) {
          this.setState({
            isSignedUp: true,
            nextUrl: "/udash/" + res.data.id
          });
        }
      });
    } else {
      this.setState({
        errors:
          "ERROR: Password and Confirm Password are not same. Please ensure that they are same."
      });
    }
  }

  onChangefullname(e) {
    this.setState({
      fullname: e.target.value
    });
  }
  onChangeusername(e) {
    this.setState({
      username_signup: e.target.value
    });
  }
  onChangeemail(e) {
    this.setState({
      email: e.target.value
    });
  }
  onChangecontact(e) {
    this.setState({
      contact: e.target.value
    });
  }
  onChangeaddress(e) {
    this.setState({
      address: e.target.value
    });
  }
  onChangecity(e) {
    this.setState({
      city: e.target.value
    });
  }
  onChangepassword(e) {
    this.setState({
      password_signup: e.target.value
    });
  }
  onChangeconfirmpassword(e) {
    this.setState({
      confirm_password: e.target.value
    });
  }

  render() {
    if (this.state.isSignedUp) {
      return <Redirect to={{ pathname: this.state.nextUrl }} />;
    } else {
      return (
        <div className="App">
          <form className="form-container" onSubmit={this.handleSubmit}>
            <h1 align="center">Sign up</h1>
            <div className="form-group">
              <p>Full Name</p>
              <input
                className="textBox"
                type="text"
                placeholder="Full Name"
                onChange={this.onChangefullname}
                required
              />
            </div>
            <div className="form-group">
              <p>UserName</p>
              <input
                className="textBox"
                type="text"
                placeholder="UserName"
                onChange={this.onChangeusername}
                required
              />
            </div>
            <div className="form-group">
              <p>E-mail</p>
              <input
                className="textBox"
                type="email"
                placeholder="E-mail"
                onChange={this.onChangeemail}
                required
              />
            </div>
            <div className="form-group">
              <p>Contact No.</p>
              <input
                className="textBox"
                type="text"
                pattern="[789][0-9]{9}"
                placeholder="Contact No."
                onChange={this.onChangecontact}
                required
              />
            </div>
            <div className="form-group">
              <p>Address</p>
              <input
                className="textBox"
                type="text"
                placeholder="Address"
                onChange={this.onChangeaddress}
                required
              />
            </div>
            <div className="form-group">
              <p>City</p>
              <input
                className="textBox"
                type="text"
                placeholder="City"
                onChange={this.onChangecity}
                required
              />
            </div>
            <Typography
              variant="h6"
              component="h6"
              color="error"
              align="center"
            >
              {this.state.errors}
            </Typography>
            <div className="form-group">
              <p>Password</p>
              <input
                className="textBox"
                type="password"
                placeholder="Password"
                onChange={this.onChangepassword}
                required
              />
            </div>
            <div className="form-group">
              <p>Confirm Password</p>
              <input
                className="textBox"
                type="password"
                placeholder="Confirm Password"
                onChange={this.onChangeconfirmpassword}
                required
              />
            </div>
            <div className="form-group text-center">
              <button type="submit" className="btn btn-primary mybtn">
                SignUp
              </button>
            </div>
          </form>
        </div>
      );
    }
  }

  // handleClick(event) {
  //   var apiBaseUrl = "https://192.168.10.202:8080";
  //   console.log(
  //     "values",
  //     this.state.fullname,
  //     this.state.username_signup,
  //     this.state.email,
  //     this.state.contact,
  //     this.state.address,
  //     this.state.city,
  //     this.state.password_signup,
  //     this.state.confirm_password
  //   );
  //   //To be done:check for empty values before hitting submit
  //   var self = this;
  //   var payload = {
  //     fullname: this.state.fullname,
  //     username_signup: this.state.username_signup,
  //     email: this.state.email,
  //     contact: this.state.contact,
  //     address: this.state.address,
  //     password_signup: this.state.password_signup,
  //     confirm_password: this.state.confirm_password
  //   };
  //   Axios.post(apiBaseUrl + "/user", payload)
  //     .then(function(response) {
  //       console.log(response);
  //       if (response.data.code == 200) {
  //         console.log("registration successfull");
  //         var loginscreen = [];
  //         loginscreen.push(<Login parentContext={this} />);
  //         var loginmessage = "Not Registered yet.Go to registration";
  //         self.props.parentContext.setState({
  //           loginscreen: loginscreen,
  //           loginmessage: loginmessage,
  //           buttonLabel: "Register",
  //           isLogin: true
  //         });
  //       }
  //     })
  //     .catch(function(error) {
  //       console.log(error);
  //     });
  // }
}

export default UserSignUp;
