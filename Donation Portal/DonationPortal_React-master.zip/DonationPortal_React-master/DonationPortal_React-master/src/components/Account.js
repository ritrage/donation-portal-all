import React from "react";
import "../styles/bootstrap.min.css";
import "../App.css";
import Nav from "./nav";
import Axios from "axios";

class Account extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      email: "",
      contact: "",
      address: "",
      city: "",
      toggle: "open",
      uid: this.props.match.params.id,
      userUrl: "http://localhost:8080/user/" + this.props.match.params.id + "/",
      ngoUrl: "http://localhost:8080/ngo/" + this.props.match.params.id + "/",
      type: this.props.match.params.type === "u" ? "USER" : "NGO"
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidMount() {
    if (this.state.type === "USER") {
      const userUrl = this.state.userUrl;
      Axios.get(userUrl).then(res => {
        console.log(res.data);
        this.setState({
          username: res.data.username,
          email: res.data.email,
          contact: res.data.contact,
          address: res.data.address,
          city: res.data.city
        });
      });
    } else if (this.state.type === "NGO") {
      const ngoUrl = this.state.ngoUrl;
      Axios.get(ngoUrl).then(res => {
        console.log(res.data);
        this.setState({
          username: res.data.ngoName,
          email: res.data.email,
          contact: res.data.contact,
          address: res.data.address,
          city: res.data.city
        });
      });
    }
  }

  handleSubmit(e) {
    e.preventDefault();
    if (this.state.toggle === "open") {
      this.setState({
        toggle: "close"
      });
      // const userId = this.state.url;
      // Axios.get(userId).then(res => {
      //   console.log(res.data);
      //   this.setState({
      //     username: res.data.username,
      //     email: res.data.email,
      //     contact: res.data.contact,
      //     address: res.data.address,
      //     city: res.data.city
      //   });
      // });
    } else if (this.state.toggle === "close") {
      this.setState({
        toggle: "open"
      });
      const saveIt = {
        id: this.state.uid,
        email: this.state.email,
        contact: this.state.contact,
        address: this.state.address,
        city: this.state.city
      };
      if (this.state.type === "USER") {
        Axios.put("http://localhost:8080/user/", saveIt);
      } else if (this.state.type === "NGO") {
        Axios.put("http://localhost:8080/ngo/", saveIt);
      }
    }
  }

  render() {
    const notedit = (
      <div className="form-container-pavbhaji">
        <h1 align="center">Account Details</h1>
        <p>Username: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.username}
          disabled
        />
        <p>E-mail Id: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.email}
          disabled
        />
        <p>Address: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.address}
          disabled
        />
        <p>City: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.city}
          disabled
        />
        <p>Contact number: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.contact}
          disabled
        />
        <div className="text-center">
          <button
            type="button"
            className="btn btn-primary mybtn"
            onClick={this.handleSubmit}
          >
            Edit
          </button>
        </div>
      </div>
    );
    const edit = (
      <div className="form-container-pavbhaji">
        <h1 align="center">Account Details</h1>
        <p>Username: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.username}
        />
        <p>E-mail Id: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.email}
          onChange={e => {
            this.setState({ email: e.target.value });
          }}
        />
        <p>Address: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.address}
          onChange={e => {
            this.setState({ address: e.target.value });
          }}
        />
        <p>City: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.city}
          onChange={e => {
            this.setState({ city: e.target.value });
          }}
        />
        <p>Contact number: </p>
        <input
          className="textBox"
          type="text"
          name="Name"
          value={this.state.contact}
          onChange={e => {
            this.setState({ contact: e.target.value });
          }}
        />
        <div className="text-center">
          <button
            type="button"
            className="btn btn-primary mybtn"
            onClick={this.handleSubmit}
          >
            Save
          </button>
        </div>
      </div>
    );
    return (
      <div>
        <Nav uid={this.state.uid} type={this.state.type} />
        {this.state.toggle === "open" ? notedit : edit}
      </div>
    );
  }
}

export default Account;
