import React, { Component } from "react";
import "./App.css";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import UserSignUp from "./components/UserSignUp";
import Login from "./components/login";
import NgoSignUp from "./components/NgoSignUp";
import UserDashboard from "./components/UserDashboard";
import NgoDashboard from "./components/NgoDashboard";
import SideNav from "./components/SideNav";
import NgoDonation from "./components/NgoDonation";
import Details_completed from "./components/details_completed";
import UserDonation from "./components/UserDonation";
import Account from "./components/Account";
import Notfound from "./components/notfound";
import Details_pending from "./components/details_pending";
import Nav from "./components/nav";
import Details_ngo_completed from "./components/details_ngo_completed";
import SideNavNgo from "./components/Sidenavngo";

class App extends Component {
  render() {
    return (
      <div>
        <BrowserRouter>
          <Switch>
            <Route exact path="/" component={Login} />
            <Route path="/login" component={Login} />
            <Route path="/signup" component={UserSignUp} />
            <Route path="/ngosu" component={NgoSignUp} />
            <Route path="/udash/:id" component={UserDashboard} />
            <Route path="/ndash/:id" component={NgoDashboard} />
            <Route path="/snav" component={SideNav} />
            <Route path="/snavngo" component={SideNavNgo} />
            <Route path="/ndon/:type/:id" component={NgoDonation} />
            <Route path="/udon/:type/:id" component={UserDonation} />
            <Route path="/acc/:type/:id" component={Account} />
            <Route path="/detailsc/:id" component={Details_completed} />
            <Route path="/detailsp/:id" component={Details_pending} />
            <Route path="/ndetailsr/:id" component={Details_ngo_completed} />
            <Route path="/nav" component={Nav} />
            <Route component={Notfound} />
          </Switch>
        </BrowserRouter>
      </div>
    );
  }
}

export default App;
